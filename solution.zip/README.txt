Suwen Ren
- get_r(), get_g(), get_b(), and get_a()
- make_pixel()
- imgproc_transpose()
- imgproc_emboss()

Anton Sackley
- is_in_ellipse()
- imgproc_complement()
- imgproc_ellipse()
